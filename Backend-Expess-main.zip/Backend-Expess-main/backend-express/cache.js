// cache.js
module.exports = {
  latestCarbon: null,
  latestMicro: null,
};
